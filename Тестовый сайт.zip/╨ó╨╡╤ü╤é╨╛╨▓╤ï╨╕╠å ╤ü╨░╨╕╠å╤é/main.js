;(function ($) {
	'use strict';

	$(function() {
		var noUiSliderBlock = document.querySelector('.noUi_block'),
			noUiTextBlock = document.querySelector('.noUi_text_block'),
			defaultCount = 2,
			yearBlock = $('.progress-circle.year'),
			progectBlock = $('.progress-circle.progect'),
			my_categories = {
				"1":{
					"time":"1",
					"progect":"80",
					"title":"Intern"
				},
				"2":{
					"time":"3",
					"progect":"120",
					"title":"Junior"
				},
				"3":{
					"time":"12",
					"progect":"256",
					"title":"Middle"
				},
				"4":{
					"time":"15",
					"progect":"330",
					"title":"Senior"
				},
				"5":{
					"time":"20",
					"progect":"500",
					"title":"Lead"
				},
			};

		$.each(my_categories, function() {
			$(noUiTextBlock).append(`<div class="noUi_text_block__item ${this.title}">${this.title}</div>`)
		})

		var yearMaximum = my_categories[Object.keys(my_categories).length].time,
			progectMaximum = my_categories[Object.keys(my_categories).length].progect;

		noUiSlider.create(noUiSliderBlock, {
			range: {
		        'min': 1,
		        'max': parseInt(Object.keys(my_categories).length )
		    },

		    step: 1,
		    connect: true,
		    start: [1,defaultCount]
		});

		noUiSliderBlock.noUiSlider.on('update.one', function (value) {
			let mas = value;
			noUiEndBlock(parseInt(mas[1]));
		});

		let count_slider = 3;

		$('.slider-block-list').on('init', function(event, slick){
			$('.slider-block__count .all_slide').text('/'+ parseInt((slick.slideCount/count_slider)+1));
		});

		$('.slider-block-list').slick({
			slidesToShow: count_slider,
  			slidesToScroll: count_slider,
  			infinite: false,
  			variableWidth: true,
  			appendArrows: $('.slider-block__button'),
  			prevArrow: '<div class="slider-block__button__prev"></div>',
  			nextArrow: '<div class="slider-block__button__next"></div>',
		
  			responsive: [
		    {
		      breakpoint: 1024,
		      settings: {
		        slidesToShow: 3,
		        slidesToScroll: 3,
		        infinite: true,
		        dots: true
		      }
		    },
		    {
		      breakpoint: 640,
		      settings: {
		        slidesToShow: 2,
		        slidesToScroll: 2
		      }
		    },
		    {
		      breakpoint: 480,
		      settings: {
		        slidesToShow: 1,
		        slidesToScroll: 1
		      }
		    }
		  ]

		});

		$('.slider-block-list').on('beforeChange', function(event, slick, currentSlide, nextSlide){
	    	$('.slider-block__count .active_slide').text(parseInt(nextSlide/count_slider+1));
	  	});

	  	$('.like_block').on('click', function() {
	  		$(this).toggleClass('active');
	  	})
	  	$('.color_list li').on('click', function() {
	  		$(this).addClass('active');
	  		$(this).siblings().removeClass('active');
	  	})

		noUiEndBlock(defaultCount);
		function noUiEndBlock(index) {

			 yearBlock.find('.count').text(my_categories[index].time)
			 progectBlock.find('.count').text(my_categories[index].progect)

			 let yearPersent = 364 - 364 * ( my_categories[index].time/yearMaximum ),
			 	progectPersent = 364 - 364 * ( my_categories[index].progect/progectMaximum );

			yearBlock.find('.progress-circle__status circle').css('stroke-dashoffset', yearPersent)
			progectBlock.find('.progress-circle__status circle').css('stroke-dashoffset', progectPersent)
		}
	})
})(jQuery);
